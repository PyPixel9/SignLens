package com.example.sign_language_undestanding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
